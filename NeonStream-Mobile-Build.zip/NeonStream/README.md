# NeonStream — Android IPTV Player (starter 0.1.0)

Projeto Android nativo em Java, com interface futurista inicial e suporte experimental a:
- Importação de playlists M3U/M3U8 por URL ou arquivo local.
- Extração de nome, `group-title` e `tvg-logo` de entradas `#EXTINF`.
- Login Xtream Codes e consulta inicial de canais ao vivo.
- Filtro por categoria e reprodução inicial usando o player nativo Android.

## Compilar pelo celular usando GitHub Actions (sem PC)

1. Extraia este ZIP no celular.
2. No navegador, abra https://github.com/ e crie uma conta gratuita ou entre na sua conta.
3. Crie um repositório chamado `NeonStream`. Para manter o código privado, escolha **Private**.
4. No repositório, use **Add file > Upload files** e envie o conteúdo da pasta `NeonStream` extraída (incluindo a pasta oculta `.github`).
   - Se o site móvel não mostrar Upload files, abra o menu do navegador e marque **Versão para computador**.
   - Confirme que `.github/workflows/android-apk.yml` foi enviado. Se o Android ocultar `.github`, crie essa estrutura pelo editor web do GitHub ou habilite mostrar arquivos ocultos no gerenciador.
5. Faça **Commit changes** na branch `main`.
6. Abra a aba **Actions**, selecione **Build NeonStream APK** e toque em **Run workflow** (ou aguarde o build disparar após o commit).
7. Quando terminar com status verde, abra a execução e baixe o artefato `NeonStream-debug-apk`.
8. Extraia o artefato ZIP no celular e toque em `app-debug.apk` para instalar. Autorize a instalação pelo navegador/gerenciador de arquivos se o Android solicitar.

O GitHub Actions oferece minutos gratuitos conforme o tipo de conta e repositório. Repositórios privados têm limites mensais; um repositório público pode tornar o código visível para todos. Confira os limites atuais antes de escolher. Não coloque listas IPTV, URLs privadas, nomes de usuário ou senhas no repositório.

## Compilar no Android Studio

1. Instale Android Studio e Android SDK Platform 35.
2. Abra a pasta `NeonStream` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Estado e limitações

Este é um protótipo inicial, não um player IPTV completo. Xtream nesta versão carrega apenas canais ao vivo. VOD, séries, EPG, favoritos persistentes, histórico, busca, atualização de playlists e proteção de credenciais ainda precisam ser implementados. O player nativo atual tem compatibilidade limitada; a próxima evolução técnica recomendada é migrar para AndroidX Media3/ExoPlayer.

O aplicativo não inclui nem fornece playlists ou canais. Use somente listas e serviços para os quais você tenha autorização.
